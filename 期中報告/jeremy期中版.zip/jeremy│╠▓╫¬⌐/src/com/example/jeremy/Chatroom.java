package com.example.jeremy;

import java.io.BufferedWriter;

import android.R.string;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;


public class Chatroom extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_chatroom);
		Button btu6=(Button)findViewById(R.id.Button6);
		btu6.setOnClickListener(buttonResponse);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.chatroom, menu);
		return true;
	}
	private OnClickListener buttonResponse = new OnClickListener() {
		public void onClick(View v) {
			TextView txvu1=(TextView)findViewById(R.id.TextView1);
			TextView txvu2=(TextView)findViewById(R.id.TextView2);
			EditText edtx1=(EditText)findViewById(R.id.EditText1);
			EditText edtx2=(EditText)findViewById(R.id.EditText2);
			txvu1.setText(edtx1.getText());
			txvu2.setText(edtx2.getText());
			}
	};

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}


